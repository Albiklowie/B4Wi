﻿namespace _1._1_FDCForLabMonitoringSystem
{
    partial class MiscTabForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MiscTabForms));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.MiscTabMainTab = new System.Windows.Forms.TabControl();
            this.tabStudents = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.StudentPCNo = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.StudentIdTextbox = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.StudentUserStatusCombobox = new System.Windows.Forms.ComboBox();
            this.StudentCourseLevelCombobox = new System.Windows.Forms.ComboBox();
            this.StudentCourseCombobox = new System.Windows.Forms.ComboBox();
            this.StudentDepartmentCombobox = new System.Windows.Forms.ComboBox();
            this.StudentGenderCombobox = new System.Windows.Forms.ComboBox();
            this.StudentFirstNameTextbox = new System.Windows.Forms.TextBox();
            this.StudentMiddleNameTextbox = new System.Windows.Forms.TextBox();
            this.StudentLastNameTextbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.StudentClearButton = new System.Windows.Forms.Button();
            this.MiscTabStudentsDGV = new System.Windows.Forms.DataGridView();
            this.StudentDeleteButton = new System.Windows.Forms.Button();
            this.StudentAddButton = new System.Windows.Forms.Button();
            this.StudentUpdateButton = new System.Windows.Forms.Button();
            this.tabInstuctors = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.InstructorClearButton = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label86 = new System.Windows.Forms.Label();
            this.InstructorPositionTextbox = new System.Windows.Forms.TextBox();
            this.InstructorUserStatusCombobox = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.InstructorMiddleNameTextbox = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.InstructorIdTextbox = new System.Windows.Forms.TextBox();
            this.InstructorLastNameTextbox = new System.Windows.Forms.TextBox();
            this.InstructorFirstNameTextbox = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.InstructorDeleteButton = new System.Windows.Forms.Button();
            this.MiscTabInstrutorsDGV = new System.Windows.Forms.DataGridView();
            this.InstructorUpdateButton = new System.Windows.Forms.Button();
            this.InstructorAddButton = new System.Windows.Forms.Button();
            this.tabLaboratoryStaffs = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.StaffClearButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.StaffPositionTextbox = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.StaffMiddleNameTextbox = new System.Windows.Forms.TextBox();
            this.StaffUserStatusCombobox = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.StaffLastNameTextbox = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.StaffFirstNameTextbox = new System.Windows.Forms.TextBox();
            this.StaffIdTextbox = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.StaffDeleteButton = new System.Windows.Forms.Button();
            this.MiscTabLaboratoryStaffDGV = new System.Windows.Forms.DataGridView();
            this.StaffUpdateButton = new System.Windows.Forms.Button();
            this.StaffAddButton = new System.Windows.Forms.Button();
            this.tabDepartment = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.MiscTabDepartmentsDGV = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.DepartmentIdTextbox = new System.Windows.Forms.TextBox();
            this.DepartmentDescriptionTextbox = new System.Windows.Forms.TextBox();
            this.DepartmentNameTextbox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.DepartmentClearButton = new System.Windows.Forms.Button();
            this.DepartmentAddButton = new System.Windows.Forms.Button();
            this.DepartmentDeleteButton = new System.Windows.Forms.Button();
            this.DepartmentUpdateButton = new System.Windows.Forms.Button();
            this.tabSchedules = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.CourseClearButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CourseIdTextbox = new System.Windows.Forms.TextBox();
            this.CourseDescriptionTextbox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.CourseStatusCombobox = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.CourseNameTextbox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.CourseDepartmentCombobox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.CourseDeleteButton = new System.Windows.Forms.Button();
            this.MiscTabCoursesDGV = new System.Windows.Forms.DataGridView();
            this.CourseUpdateButton = new System.Windows.Forms.Button();
            this.CourseAddButton = new System.Windows.Forms.Button();
            this.tabAttendance = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.SubjectClearButton = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.SubjectCourseCombobox = new System.Windows.Forms.ComboBox();
            this.SubjectUnitsToCompleteTextbox = new System.Windows.Forms.TextBox();
            this.SubjectIdTextbox = new System.Windows.Forms.TextBox();
            this.SubjectDescriptionTextbox = new System.Windows.Forms.TextBox();
            this.SubjectNameTextbox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.SubjectDeleteButton = new System.Windows.Forms.Button();
            this.MiscTabSubjectDGV = new System.Windows.Forms.DataGridView();
            this.SujectUpdateButton = new System.Windows.Forms.Button();
            this.SubjectAddButton = new System.Windows.Forms.Button();
            this.tabFacilities = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.FacilityClearButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FacilityIdTextbox = new System.Windows.Forms.TextBox();
            this.FacilityDescriptionTextbox = new System.Windows.Forms.TextBox();
            this.FacilityNameTextbox = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.FacilityDeleteButton = new System.Windows.Forms.Button();
            this.MiscTabFacilitiesDGV = new System.Windows.Forms.DataGridView();
            this.FacilityUpdateButton = new System.Windows.Forms.Button();
            this.FacilityAddButton = new System.Windows.Forms.Button();
            this.tabSchedule = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.ScheduleClearButton = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label49 = new System.Windows.Forms.Label();
            this.SchedulesInstructorIdCombobox = new System.Windows.Forms.ComboBox();
            this.ScheduleTimeEndDTP = new System.Windows.Forms.DateTimePicker();
            this.ScheduleTimeStartDTP = new System.Windows.Forms.DateTimePicker();
            this.ScheduleSemesterTextbox = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.ScheduleValidUntilDTP = new System.Windows.Forms.DateTimePicker();
            this.ScheduleValidOnDTP = new System.Windows.Forms.DateTimePicker();
            this.ScheduleSubjectCombobox = new System.Windows.Forms.ComboBox();
            this.ScheduleStatusCombobox = new System.Windows.Forms.ComboBox();
            this.ScheduleFacilityCombobox = new System.Windows.Forms.ComboBox();
            this.ScheduleIdTextbox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.ScheduleDeleteButton = new System.Windows.Forms.Button();
            this.MiscTabSchedulesDGV = new System.Windows.Forms.DataGridView();
            this.ScheduleUpdateButton = new System.Windows.Forms.Button();
            this.ScheduleAddButton = new System.Windows.Forms.Button();
            this.tabAttendace = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.AttendanceSearchTextbox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.AttendanceScheduleIdTextbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AttendanceStudentIdTextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TimeOutDTP = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.TimeInDTP = new System.Windows.Forms.DateTimePicker();
            this.AttendanceDateDTP = new System.Windows.Forms.DateTimePicker();
            this.label32 = new System.Windows.Forms.Label();
            this.AttendanceFindButton = new System.Windows.Forms.Button();
            this.MiscTabAttendanceDGV = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.MiscTabMainTab.SuspendLayout();
            this.tabStudents.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabStudentsDGV)).BeginInit();
            this.tabInstuctors.SuspendLayout();
            this.panel11.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabInstrutorsDGV)).BeginInit();
            this.tabLaboratoryStaffs.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabLaboratoryStaffDGV)).BeginInit();
            this.tabDepartment.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabDepartmentsDGV)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.tabSchedules.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabCoursesDGV)).BeginInit();
            this.tabAttendance.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabSubjectDGV)).BeginInit();
            this.tabFacilities.SuspendLayout();
            this.panel10.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabFacilitiesDGV)).BeginInit();
            this.tabSchedule.SuspendLayout();
            this.panel8.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabSchedulesDGV)).BeginInit();
            this.tabAttendace.SuspendLayout();
            this.panel9.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabAttendanceDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1206, 50);
            this.panel2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gotham Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 32);
            this.label2.TabIndex = 26;
            this.label2.Text = "System Maintenance";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(1156, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 25;
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MiscTabMainTab
            // 
            this.MiscTabMainTab.Controls.Add(this.tabStudents);
            this.MiscTabMainTab.Controls.Add(this.tabInstuctors);
            this.MiscTabMainTab.Controls.Add(this.tabLaboratoryStaffs);
            this.MiscTabMainTab.Controls.Add(this.tabDepartment);
            this.MiscTabMainTab.Controls.Add(this.tabSchedules);
            this.MiscTabMainTab.Controls.Add(this.tabAttendance);
            this.MiscTabMainTab.Controls.Add(this.tabFacilities);
            this.MiscTabMainTab.Controls.Add(this.tabSchedule);
            this.MiscTabMainTab.Controls.Add(this.tabAttendace);
            this.MiscTabMainTab.Font = new System.Drawing.Font("Gotham Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MiscTabMainTab.HotTrack = true;
            this.MiscTabMainTab.Location = new System.Drawing.Point(12, 60);
            this.MiscTabMainTab.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MiscTabMainTab.Name = "MiscTabMainTab";
            this.MiscTabMainTab.SelectedIndex = 0;
            this.MiscTabMainTab.Size = new System.Drawing.Size(1186, 476);
            this.MiscTabMainTab.TabIndex = 6;
            // 
            // tabStudents
            // 
            this.tabStudents.BackColor = System.Drawing.Color.White;
            this.tabStudents.Controls.Add(this.panel1);
            this.tabStudents.Location = new System.Drawing.Point(4, 28);
            this.tabStudents.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabStudents.Name = "tabStudents";
            this.tabStudents.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabStudents.Size = new System.Drawing.Size(1178, 444);
            this.tabStudents.TabIndex = 0;
            this.tabStudents.Text = "Students";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.StudentClearButton);
            this.panel1.Controls.Add(this.MiscTabStudentsDGV);
            this.panel1.Controls.Add(this.StudentDeleteButton);
            this.panel1.Controls.Add(this.StudentAddButton);
            this.panel1.Controls.Add(this.StudentUpdateButton);
            this.panel1.Font = new System.Drawing.Font("Gotham Book", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(7, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1164, 426);
            this.panel1.TabIndex = 11;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.StudentPCNo);
            this.groupBox5.Controls.Add(this.label50);
            this.groupBox5.Controls.Add(this.StudentIdTextbox);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.StudentUserStatusCombobox);
            this.groupBox5.Controls.Add(this.StudentCourseLevelCombobox);
            this.groupBox5.Controls.Add(this.StudentCourseCombobox);
            this.groupBox5.Controls.Add(this.StudentDepartmentCombobox);
            this.groupBox5.Controls.Add(this.StudentGenderCombobox);
            this.groupBox5.Controls.Add(this.StudentFirstNameTextbox);
            this.groupBox5.Controls.Add(this.StudentMiddleNameTextbox);
            this.groupBox5.Controls.Add(this.StudentLastNameTextbox);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(467, 366);
            this.groupBox5.TabIndex = 43;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Student Details";
            // 
            // StudentPCNo
            // 
            this.StudentPCNo.Location = new System.Drawing.Point(149, 326);
            this.StudentPCNo.Name = "StudentPCNo";
            this.StudentPCNo.Size = new System.Drawing.Size(121, 27);
            this.StudentPCNo.TabIndex = 10;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(16, 331);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(64, 19);
            this.label50.TabIndex = 30;
            this.label50.Text = "PC No.";
            // 
            // StudentIdTextbox
            // 
            this.StudentIdTextbox.Location = new System.Drawing.Point(149, 29);
            this.StudentIdTextbox.Name = "StudentIdTextbox";
            this.StudentIdTextbox.Size = new System.Drawing.Size(125, 27);
            this.StudentIdTextbox.TabIndex = 1;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(16, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(92, 19);
            this.label33.TabIndex = 28;
            this.label33.Text = "Student Id";
            // 
            // StudentUserStatusCombobox
            // 
            this.StudentUserStatusCombobox.FormattingEnabled = true;
            this.StudentUserStatusCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.StudentUserStatusCombobox.Location = new System.Drawing.Point(149, 293);
            this.StudentUserStatusCombobox.Name = "StudentUserStatusCombobox";
            this.StudentUserStatusCombobox.Size = new System.Drawing.Size(121, 27);
            this.StudentUserStatusCombobox.TabIndex = 9;
            // 
            // StudentCourseLevelCombobox
            // 
            this.StudentCourseLevelCombobox.FormattingEnabled = true;
            this.StudentCourseLevelCombobox.Items.AddRange(new object[] {
            " First year ",
            "Second year",
            "Third year",
            "Fourth year",
            "Fifth year"});
            this.StudentCourseLevelCombobox.Location = new System.Drawing.Point(149, 260);
            this.StudentCourseLevelCombobox.Name = "StudentCourseLevelCombobox";
            this.StudentCourseLevelCombobox.Size = new System.Drawing.Size(121, 27);
            this.StudentCourseLevelCombobox.TabIndex = 8;
            // 
            // StudentCourseCombobox
            // 
            this.StudentCourseCombobox.FormattingEnabled = true;
            this.StudentCourseCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.StudentCourseCombobox.Location = new System.Drawing.Point(149, 227);
            this.StudentCourseCombobox.Name = "StudentCourseCombobox";
            this.StudentCourseCombobox.Size = new System.Drawing.Size(300, 27);
            this.StudentCourseCombobox.TabIndex = 7;
            // 
            // StudentDepartmentCombobox
            // 
            this.StudentDepartmentCombobox.FormattingEnabled = true;
            this.StudentDepartmentCombobox.Location = new System.Drawing.Point(149, 194);
            this.StudentDepartmentCombobox.Name = "StudentDepartmentCombobox";
            this.StudentDepartmentCombobox.Size = new System.Drawing.Size(300, 27);
            this.StudentDepartmentCombobox.TabIndex = 6;
            // 
            // StudentGenderCombobox
            // 
            this.StudentGenderCombobox.FormattingEnabled = true;
            this.StudentGenderCombobox.Items.AddRange(new object[] {
            "Female",
            "Male"});
            this.StudentGenderCombobox.Location = new System.Drawing.Point(149, 161);
            this.StudentGenderCombobox.Name = "StudentGenderCombobox";
            this.StudentGenderCombobox.Size = new System.Drawing.Size(121, 27);
            this.StudentGenderCombobox.TabIndex = 5;
            // 
            // StudentFirstNameTextbox
            // 
            this.StudentFirstNameTextbox.Location = new System.Drawing.Point(149, 62);
            this.StudentFirstNameTextbox.Name = "StudentFirstNameTextbox";
            this.StudentFirstNameTextbox.Size = new System.Drawing.Size(300, 27);
            this.StudentFirstNameTextbox.TabIndex = 2;
            // 
            // StudentMiddleNameTextbox
            // 
            this.StudentMiddleNameTextbox.Location = new System.Drawing.Point(149, 128);
            this.StudentMiddleNameTextbox.Name = "StudentMiddleNameTextbox";
            this.StudentMiddleNameTextbox.Size = new System.Drawing.Size(300, 27);
            this.StudentMiddleNameTextbox.TabIndex = 4;
            // 
            // StudentLastNameTextbox
            // 
            this.StudentLastNameTextbox.Location = new System.Drawing.Point(149, 95);
            this.StudentLastNameTextbox.Name = "StudentLastNameTextbox";
            this.StudentLastNameTextbox.Size = new System.Drawing.Size(300, 27);
            this.StudentLastNameTextbox.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 19);
            this.label10.TabIndex = 11;
            this.label10.Text = "First Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 99);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 19);
            this.label11.TabIndex = 10;
            this.label11.Text = "Last Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 132);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 19);
            this.label9.TabIndex = 12;
            this.label9.Text = "Middle Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 19);
            this.label8.TabIndex = 13;
            this.label8.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 198);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 19);
            this.label7.TabIndex = 14;
            this.label7.Text = "Department";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(16, 297);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(98, 19);
            this.label35.TabIndex = 17;
            this.label35.Text = "User Status";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(16, 264);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(110, 19);
            this.label37.TabIndex = 15;
            this.label37.Text = "Course Level";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(16, 231);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(64, 19);
            this.label36.TabIndex = 16;
            this.label36.Text = "Course";
            // 
            // StudentClearButton
            // 
            this.StudentClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StudentClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StudentClearButton.FlatAppearance.BorderSize = 0;
            this.StudentClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StudentClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentClearButton.ForeColor = System.Drawing.Color.White;
            this.StudentClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentClearButton.Location = new System.Drawing.Point(264, 395);
            this.StudentClearButton.Name = "StudentClearButton";
            this.StudentClearButton.Size = new System.Drawing.Size(125, 28);
            this.StudentClearButton.TabIndex = 42;
            this.StudentClearButton.Text = "Clear";
            this.StudentClearButton.UseVisualStyleBackColor = false;
            this.StudentClearButton.Click += new System.EventHandler(this.button4_Click);
            // 
            // MiscTabStudentsDGV
            // 
            this.MiscTabStudentsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabStudentsDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabStudentsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabStudentsDGV.Location = new System.Drawing.Point(476, 11);
            this.MiscTabStudentsDGV.Name = "MiscTabStudentsDGV";
            this.MiscTabStudentsDGV.Size = new System.Drawing.Size(685, 358);
            this.MiscTabStudentsDGV.TabIndex = 9;
            this.MiscTabStudentsDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabStudentsDGV_RowHeaderMouseClick);
            // 
            // StudentDeleteButton
            // 
            this.StudentDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StudentDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StudentDeleteButton.FlatAppearance.BorderSize = 0;
            this.StudentDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StudentDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentDeleteButton.ForeColor = System.Drawing.Color.White;
            this.StudentDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentDeleteButton.Location = new System.Drawing.Point(133, 395);
            this.StudentDeleteButton.Name = "StudentDeleteButton";
            this.StudentDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.StudentDeleteButton.TabIndex = 41;
            this.StudentDeleteButton.Text = "Delete";
            this.StudentDeleteButton.UseVisualStyleBackColor = false;
            this.StudentDeleteButton.Click += new System.EventHandler(this.StudentDeleteButton_Click);
            // 
            // StudentAddButton
            // 
            this.StudentAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StudentAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StudentAddButton.FlatAppearance.BorderSize = 0;
            this.StudentAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StudentAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentAddButton.ForeColor = System.Drawing.Color.White;
            this.StudentAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentAddButton.Location = new System.Drawing.Point(471, 395);
            this.StudentAddButton.Name = "StudentAddButton";
            this.StudentAddButton.Size = new System.Drawing.Size(125, 28);
            this.StudentAddButton.TabIndex = 39;
            this.StudentAddButton.Text = "Add Student";
            this.StudentAddButton.UseVisualStyleBackColor = false;
            this.StudentAddButton.Click += new System.EventHandler(this.StudentAddButton_Click);
            // 
            // StudentUpdateButton
            // 
            this.StudentUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StudentUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StudentUpdateButton.FlatAppearance.BorderSize = 0;
            this.StudentUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StudentUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentUpdateButton.ForeColor = System.Drawing.Color.White;
            this.StudentUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentUpdateButton.Location = new System.Drawing.Point(2, 395);
            this.StudentUpdateButton.Name = "StudentUpdateButton";
            this.StudentUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.StudentUpdateButton.TabIndex = 40;
            this.StudentUpdateButton.Text = "Update";
            this.StudentUpdateButton.UseVisualStyleBackColor = false;
            this.StudentUpdateButton.Click += new System.EventHandler(this.StudentUpdateButton_Click);
            // 
            // tabInstuctors
            // 
            this.tabInstuctors.BackColor = System.Drawing.Color.White;
            this.tabInstuctors.Controls.Add(this.panel11);
            this.tabInstuctors.Location = new System.Drawing.Point(4, 28);
            this.tabInstuctors.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabInstuctors.Name = "tabInstuctors";
            this.tabInstuctors.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabInstuctors.Size = new System.Drawing.Size(1178, 444);
            this.tabInstuctors.TabIndex = 1;
            this.tabInstuctors.Text = "Instructors";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.InstructorClearButton);
            this.panel11.Controls.Add(this.groupBox7);
            this.panel11.Controls.Add(this.InstructorDeleteButton);
            this.panel11.Controls.Add(this.MiscTabInstrutorsDGV);
            this.panel11.Controls.Add(this.InstructorUpdateButton);
            this.panel11.Controls.Add(this.InstructorAddButton);
            this.panel11.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel11.Location = new System.Drawing.Point(7, 8);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1164, 426);
            this.panel11.TabIndex = 13;
            // 
            // InstructorClearButton
            // 
            this.InstructorClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.InstructorClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.InstructorClearButton.FlatAppearance.BorderSize = 0;
            this.InstructorClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.InstructorClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InstructorClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructorClearButton.ForeColor = System.Drawing.Color.White;
            this.InstructorClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InstructorClearButton.Location = new System.Drawing.Point(265, 284);
            this.InstructorClearButton.Name = "InstructorClearButton";
            this.InstructorClearButton.Size = new System.Drawing.Size(125, 28);
            this.InstructorClearButton.TabIndex = 57;
            this.InstructorClearButton.Text = "Clear";
            this.InstructorClearButton.UseVisualStyleBackColor = false;
            this.InstructorClearButton.Click += new System.EventHandler(this.InstructorClearButton_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label86);
            this.groupBox7.Controls.Add(this.InstructorPositionTextbox);
            this.groupBox7.Controls.Add(this.InstructorUserStatusCombobox);
            this.groupBox7.Controls.Add(this.label82);
            this.groupBox7.Controls.Add(this.label84);
            this.groupBox7.Controls.Add(this.InstructorMiddleNameTextbox);
            this.groupBox7.Controls.Add(this.label85);
            this.groupBox7.Controls.Add(this.InstructorIdTextbox);
            this.groupBox7.Controls.Add(this.InstructorLastNameTextbox);
            this.groupBox7.Controls.Add(this.InstructorFirstNameTextbox);
            this.groupBox7.Controls.Add(this.label81);
            this.groupBox7.Controls.Add(this.label83);
            this.groupBox7.Location = new System.Drawing.Point(3, 3);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(479, 275);
            this.groupBox7.TabIndex = 53;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Instructor Details";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(23, 173);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(72, 19);
            this.label86.TabIndex = 65;
            this.label86.Text = "Position";
            // 
            // InstructorPositionTextbox
            // 
            this.InstructorPositionTextbox.Location = new System.Drawing.Point(171, 169);
            this.InstructorPositionTextbox.Name = "InstructorPositionTextbox";
            this.InstructorPositionTextbox.Size = new System.Drawing.Size(293, 27);
            this.InstructorPositionTextbox.TabIndex = 66;
            // 
            // InstructorUserStatusCombobox
            // 
            this.InstructorUserStatusCombobox.FormattingEnabled = true;
            this.InstructorUserStatusCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.InstructorUserStatusCombobox.Location = new System.Drawing.Point(171, 202);
            this.InstructorUserStatusCombobox.Name = "InstructorUserStatusCombobox";
            this.InstructorUserStatusCombobox.Size = new System.Drawing.Size(121, 27);
            this.InstructorUserStatusCombobox.TabIndex = 64;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(21, 206);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(98, 19);
            this.label82.TabIndex = 63;
            this.label82.Text = "User Status";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(23, 140);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(113, 19);
            this.label84.TabIndex = 61;
            this.label84.Text = "Middle Name";
            // 
            // InstructorMiddleNameTextbox
            // 
            this.InstructorMiddleNameTextbox.Location = new System.Drawing.Point(171, 136);
            this.InstructorMiddleNameTextbox.Name = "InstructorMiddleNameTextbox";
            this.InstructorMiddleNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.InstructorMiddleNameTextbox.TabIndex = 62;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(23, 107);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(93, 19);
            this.label85.TabIndex = 23;
            this.label85.Text = "Last Name";
            // 
            // InstructorIdTextbox
            // 
            this.InstructorIdTextbox.Location = new System.Drawing.Point(171, 37);
            this.InstructorIdTextbox.Name = "InstructorIdTextbox";
            this.InstructorIdTextbox.Size = new System.Drawing.Size(125, 27);
            this.InstructorIdTextbox.TabIndex = 1;
            // 
            // InstructorLastNameTextbox
            // 
            this.InstructorLastNameTextbox.Location = new System.Drawing.Point(171, 103);
            this.InstructorLastNameTextbox.Name = "InstructorLastNameTextbox";
            this.InstructorLastNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.InstructorLastNameTextbox.TabIndex = 22;
            // 
            // InstructorFirstNameTextbox
            // 
            this.InstructorFirstNameTextbox.Location = new System.Drawing.Point(171, 70);
            this.InstructorFirstNameTextbox.Name = "InstructorFirstNameTextbox";
            this.InstructorFirstNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.InstructorFirstNameTextbox.TabIndex = 2;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(23, 41);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(106, 19);
            this.label81.TabIndex = 17;
            this.label81.Text = "Instructor Id";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(23, 73);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(94, 19);
            this.label83.TabIndex = 18;
            this.label83.Text = "First Name";
            // 
            // InstructorDeleteButton
            // 
            this.InstructorDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.InstructorDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.InstructorDeleteButton.FlatAppearance.BorderSize = 0;
            this.InstructorDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.InstructorDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InstructorDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructorDeleteButton.ForeColor = System.Drawing.Color.White;
            this.InstructorDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InstructorDeleteButton.Location = new System.Drawing.Point(134, 284);
            this.InstructorDeleteButton.Name = "InstructorDeleteButton";
            this.InstructorDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.InstructorDeleteButton.TabIndex = 56;
            this.InstructorDeleteButton.Text = "Delete";
            this.InstructorDeleteButton.UseVisualStyleBackColor = false;
            this.InstructorDeleteButton.Click += new System.EventHandler(this.InstructorDeleteButton_Click);
            // 
            // MiscTabInstrutorsDGV
            // 
            this.MiscTabInstrutorsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabInstrutorsDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabInstrutorsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabInstrutorsDGV.Location = new System.Drawing.Point(488, 3);
            this.MiscTabInstrutorsDGV.Name = "MiscTabInstrutorsDGV";
            this.MiscTabInstrutorsDGV.Size = new System.Drawing.Size(673, 275);
            this.MiscTabInstrutorsDGV.TabIndex = 52;
            this.MiscTabInstrutorsDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabInstrutorsDGV_RowHeaderMouseClick);
            // 
            // InstructorUpdateButton
            // 
            this.InstructorUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.InstructorUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.InstructorUpdateButton.FlatAppearance.BorderSize = 0;
            this.InstructorUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.InstructorUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InstructorUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructorUpdateButton.ForeColor = System.Drawing.Color.White;
            this.InstructorUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InstructorUpdateButton.Location = new System.Drawing.Point(3, 284);
            this.InstructorUpdateButton.Name = "InstructorUpdateButton";
            this.InstructorUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.InstructorUpdateButton.TabIndex = 55;
            this.InstructorUpdateButton.Text = "Update";
            this.InstructorUpdateButton.UseVisualStyleBackColor = false;
            this.InstructorUpdateButton.Click += new System.EventHandler(this.InstructorUpdateButton_Click);
            // 
            // InstructorAddButton
            // 
            this.InstructorAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.InstructorAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.InstructorAddButton.FlatAppearance.BorderSize = 0;
            this.InstructorAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.InstructorAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InstructorAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructorAddButton.ForeColor = System.Drawing.Color.White;
            this.InstructorAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InstructorAddButton.Location = new System.Drawing.Point(488, 284);
            this.InstructorAddButton.Name = "InstructorAddButton";
            this.InstructorAddButton.Size = new System.Drawing.Size(125, 28);
            this.InstructorAddButton.TabIndex = 54;
            this.InstructorAddButton.Text = "Add Instructor";
            this.InstructorAddButton.UseVisualStyleBackColor = false;
            this.InstructorAddButton.Click += new System.EventHandler(this.InstructorAddButton_Click);
            // 
            // tabLaboratoryStaffs
            // 
            this.tabLaboratoryStaffs.Controls.Add(this.panel7);
            this.tabLaboratoryStaffs.Location = new System.Drawing.Point(4, 28);
            this.tabLaboratoryStaffs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabLaboratoryStaffs.Name = "tabLaboratoryStaffs";
            this.tabLaboratoryStaffs.Size = new System.Drawing.Size(1178, 444);
            this.tabLaboratoryStaffs.TabIndex = 2;
            this.tabLaboratoryStaffs.Text = "Laboratory Staff";
            this.tabLaboratoryStaffs.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.StaffClearButton);
            this.panel7.Controls.Add(this.groupBox4);
            this.panel7.Controls.Add(this.StaffDeleteButton);
            this.panel7.Controls.Add(this.MiscTabLaboratoryStaffDGV);
            this.panel7.Controls.Add(this.StaffUpdateButton);
            this.panel7.Controls.Add(this.StaffAddButton);
            this.panel7.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1172, 426);
            this.panel7.TabIndex = 13;
            // 
            // StaffClearButton
            // 
            this.StaffClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StaffClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StaffClearButton.FlatAppearance.BorderSize = 0;
            this.StaffClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StaffClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StaffClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StaffClearButton.ForeColor = System.Drawing.Color.White;
            this.StaffClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StaffClearButton.Location = new System.Drawing.Point(265, 253);
            this.StaffClearButton.Name = "StaffClearButton";
            this.StaffClearButton.Size = new System.Drawing.Size(125, 28);
            this.StaffClearButton.TabIndex = 50;
            this.StaffClearButton.Text = "Clear";
            this.StaffClearButton.UseVisualStyleBackColor = false;
            this.StaffClearButton.Click += new System.EventHandler(this.StaffClearButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.StaffPositionTextbox);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.StaffMiddleNameTextbox);
            this.groupBox4.Controls.Add(this.StaffUserStatusCombobox);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.StaffLastNameTextbox);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.StaffFirstNameTextbox);
            this.groupBox4.Controls.Add(this.StaffIdTextbox);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(473, 244);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Laboratory Staff Details";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(33, 170);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 19);
            this.label22.TabIndex = 77;
            this.label22.Text = "Position";
            // 
            // StaffPositionTextbox
            // 
            this.StaffPositionTextbox.Location = new System.Drawing.Point(166, 166);
            this.StaffPositionTextbox.Name = "StaffPositionTextbox";
            this.StaffPositionTextbox.Size = new System.Drawing.Size(293, 27);
            this.StaffPositionTextbox.TabIndex = 78;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(-119, 156);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(72, 19);
            this.label42.TabIndex = 75;
            this.label42.Text = "Position";
            // 
            // StaffMiddleNameTextbox
            // 
            this.StaffMiddleNameTextbox.Location = new System.Drawing.Point(166, 133);
            this.StaffMiddleNameTextbox.Name = "StaffMiddleNameTextbox";
            this.StaffMiddleNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.StaffMiddleNameTextbox.TabIndex = 76;
            // 
            // StaffUserStatusCombobox
            // 
            this.StaffUserStatusCombobox.FormattingEnabled = true;
            this.StaffUserStatusCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.StaffUserStatusCombobox.Location = new System.Drawing.Point(166, 199);
            this.StaffUserStatusCombobox.Name = "StaffUserStatusCombobox";
            this.StaffUserStatusCombobox.Size = new System.Drawing.Size(121, 27);
            this.StaffUserStatusCombobox.TabIndex = 74;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(33, 203);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(98, 19);
            this.label43.TabIndex = 73;
            this.label43.Text = "User Status";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(33, 137);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(113, 19);
            this.label44.TabIndex = 71;
            this.label44.Text = "Middle Name";
            // 
            // StaffLastNameTextbox
            // 
            this.StaffLastNameTextbox.Location = new System.Drawing.Point(166, 100);
            this.StaffLastNameTextbox.Name = "StaffLastNameTextbox";
            this.StaffLastNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.StaffLastNameTextbox.TabIndex = 72;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(33, 104);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(93, 19);
            this.label45.TabIndex = 70;
            this.label45.Text = "Last Name";
            // 
            // StaffFirstNameTextbox
            // 
            this.StaffFirstNameTextbox.Location = new System.Drawing.Point(166, 67);
            this.StaffFirstNameTextbox.Name = "StaffFirstNameTextbox";
            this.StaffFirstNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.StaffFirstNameTextbox.TabIndex = 69;
            // 
            // StaffIdTextbox
            // 
            this.StaffIdTextbox.Location = new System.Drawing.Point(166, 34);
            this.StaffIdTextbox.Name = "StaffIdTextbox";
            this.StaffIdTextbox.Size = new System.Drawing.Size(125, 27);
            this.StaffIdTextbox.TabIndex = 68;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(33, 71);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(94, 19);
            this.label46.TabIndex = 67;
            this.label46.Text = "First Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(33, 38);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 19);
            this.label25.TabIndex = 11;
            this.label25.Text = "Staff Id";
            // 
            // StaffDeleteButton
            // 
            this.StaffDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StaffDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StaffDeleteButton.FlatAppearance.BorderSize = 0;
            this.StaffDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StaffDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StaffDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StaffDeleteButton.ForeColor = System.Drawing.Color.White;
            this.StaffDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StaffDeleteButton.Location = new System.Drawing.Point(134, 253);
            this.StaffDeleteButton.Name = "StaffDeleteButton";
            this.StaffDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.StaffDeleteButton.TabIndex = 49;
            this.StaffDeleteButton.Text = "Delete";
            this.StaffDeleteButton.UseVisualStyleBackColor = false;
            this.StaffDeleteButton.Click += new System.EventHandler(this.StaffDeleteButton_Click);
            // 
            // MiscTabLaboratoryStaffDGV
            // 
            this.MiscTabLaboratoryStaffDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabLaboratoryStaffDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabLaboratoryStaffDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabLaboratoryStaffDGV.Location = new System.Drawing.Point(491, 12);
            this.MiscTabLaboratoryStaffDGV.Name = "MiscTabLaboratoryStaffDGV";
            this.MiscTabLaboratoryStaffDGV.Size = new System.Drawing.Size(678, 235);
            this.MiscTabLaboratoryStaffDGV.TabIndex = 9;
            this.MiscTabLaboratoryStaffDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabLaboratoryStaffDGV_RowHeaderMouseClick);
            // 
            // StaffUpdateButton
            // 
            this.StaffUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StaffUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StaffUpdateButton.FlatAppearance.BorderSize = 0;
            this.StaffUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StaffUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StaffUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StaffUpdateButton.ForeColor = System.Drawing.Color.White;
            this.StaffUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StaffUpdateButton.Location = new System.Drawing.Point(3, 253);
            this.StaffUpdateButton.Name = "StaffUpdateButton";
            this.StaffUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.StaffUpdateButton.TabIndex = 48;
            this.StaffUpdateButton.Text = "Update";
            this.StaffUpdateButton.UseVisualStyleBackColor = false;
            this.StaffUpdateButton.Click += new System.EventHandler(this.StaffUpdateButton_Click);
            // 
            // StaffAddButton
            // 
            this.StaffAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.StaffAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StaffAddButton.FlatAppearance.BorderSize = 0;
            this.StaffAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.StaffAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StaffAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StaffAddButton.ForeColor = System.Drawing.Color.White;
            this.StaffAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StaffAddButton.Location = new System.Drawing.Point(491, 253);
            this.StaffAddButton.Name = "StaffAddButton";
            this.StaffAddButton.Size = new System.Drawing.Size(125, 28);
            this.StaffAddButton.TabIndex = 47;
            this.StaffAddButton.Text = "Add Staff";
            this.StaffAddButton.UseVisualStyleBackColor = false;
            this.StaffAddButton.Click += new System.EventHandler(this.StaffAddButton_Click);
            // 
            // tabDepartment
            // 
            this.tabDepartment.Controls.Add(this.panel3);
            this.tabDepartment.Location = new System.Drawing.Point(4, 28);
            this.tabDepartment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabDepartment.Name = "tabDepartment";
            this.tabDepartment.Size = new System.Drawing.Size(1178, 444);
            this.tabDepartment.TabIndex = 3;
            this.tabDepartment.Text = "Departments";
            this.tabDepartment.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.MiscTabDepartmentsDGV);
            this.panel3.Controls.Add(this.groupBox9);
            this.panel3.Controls.Add(this.DepartmentClearButton);
            this.panel3.Controls.Add(this.DepartmentAddButton);
            this.panel3.Controls.Add(this.DepartmentDeleteButton);
            this.panel3.Controls.Add(this.DepartmentUpdateButton);
            this.panel3.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1172, 426);
            this.panel3.TabIndex = 12;
            // 
            // MiscTabDepartmentsDGV
            // 
            this.MiscTabDepartmentsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabDepartmentsDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabDepartmentsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabDepartmentsDGV.Location = new System.Drawing.Point(510, 3);
            this.MiscTabDepartmentsDGV.Name = "MiscTabDepartmentsDGV";
            this.MiscTabDepartmentsDGV.Size = new System.Drawing.Size(659, 161);
            this.MiscTabDepartmentsDGV.TabIndex = 55;
            this.MiscTabDepartmentsDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabDepartmentsDGV_RowHeaderMouseClick);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.DepartmentIdTextbox);
            this.groupBox9.Controls.Add(this.DepartmentDescriptionTextbox);
            this.groupBox9.Controls.Add(this.DepartmentNameTextbox);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.label38);
            this.groupBox9.Controls.Add(this.label47);
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(501, 161);
            this.groupBox9.TabIndex = 22;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Departments Details";
            // 
            // DepartmentIdTextbox
            // 
            this.DepartmentIdTextbox.Enabled = false;
            this.DepartmentIdTextbox.Location = new System.Drawing.Point(189, 29);
            this.DepartmentIdTextbox.Name = "DepartmentIdTextbox";
            this.DepartmentIdTextbox.Size = new System.Drawing.Size(100, 27);
            this.DepartmentIdTextbox.TabIndex = 20;
            // 
            // DepartmentDescriptionTextbox
            // 
            this.DepartmentDescriptionTextbox.Location = new System.Drawing.Point(189, 95);
            this.DepartmentDescriptionTextbox.Name = "DepartmentDescriptionTextbox";
            this.DepartmentDescriptionTextbox.Size = new System.Drawing.Size(293, 27);
            this.DepartmentDescriptionTextbox.TabIndex = 22;
            // 
            // DepartmentNameTextbox
            // 
            this.DepartmentNameTextbox.Location = new System.Drawing.Point(189, 62);
            this.DepartmentNameTextbox.Name = "DepartmentNameTextbox";
            this.DepartmentNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.DepartmentNameTextbox.TabIndex = 21;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(23, 33);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(124, 19);
            this.label34.TabIndex = 17;
            this.label34.Text = "Department Id";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(23, 99);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(99, 19);
            this.label38.TabIndex = 19;
            this.label38.Text = "Description";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(23, 66);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(154, 19);
            this.label47.TabIndex = 18;
            this.label47.Text = "Department Name";
            // 
            // DepartmentClearButton
            // 
            this.DepartmentClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.DepartmentClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DepartmentClearButton.FlatAppearance.BorderSize = 0;
            this.DepartmentClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.DepartmentClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DepartmentClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentClearButton.ForeColor = System.Drawing.Color.White;
            this.DepartmentClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DepartmentClearButton.Location = new System.Drawing.Point(265, 170);
            this.DepartmentClearButton.Name = "DepartmentClearButton";
            this.DepartmentClearButton.Size = new System.Drawing.Size(125, 28);
            this.DepartmentClearButton.TabIndex = 54;
            this.DepartmentClearButton.Text = "Clear";
            this.DepartmentClearButton.UseVisualStyleBackColor = false;
            this.DepartmentClearButton.Click += new System.EventHandler(this.DepartmentClearButton_Click);
            // 
            // DepartmentAddButton
            // 
            this.DepartmentAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.DepartmentAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DepartmentAddButton.FlatAppearance.BorderSize = 0;
            this.DepartmentAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.DepartmentAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DepartmentAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentAddButton.ForeColor = System.Drawing.Color.White;
            this.DepartmentAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DepartmentAddButton.Location = new System.Drawing.Point(510, 170);
            this.DepartmentAddButton.Name = "DepartmentAddButton";
            this.DepartmentAddButton.Size = new System.Drawing.Size(142, 28);
            this.DepartmentAddButton.TabIndex = 51;
            this.DepartmentAddButton.Text = "Add Department";
            this.DepartmentAddButton.UseVisualStyleBackColor = false;
            this.DepartmentAddButton.Click += new System.EventHandler(this.DepartmentAddButton_Click);
            // 
            // DepartmentDeleteButton
            // 
            this.DepartmentDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.DepartmentDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DepartmentDeleteButton.FlatAppearance.BorderSize = 0;
            this.DepartmentDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.DepartmentDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DepartmentDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentDeleteButton.ForeColor = System.Drawing.Color.White;
            this.DepartmentDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DepartmentDeleteButton.Location = new System.Drawing.Point(134, 170);
            this.DepartmentDeleteButton.Name = "DepartmentDeleteButton";
            this.DepartmentDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.DepartmentDeleteButton.TabIndex = 53;
            this.DepartmentDeleteButton.Text = "Delete";
            this.DepartmentDeleteButton.UseVisualStyleBackColor = false;
            this.DepartmentDeleteButton.Click += new System.EventHandler(this.DepartmentDeleteButton_Click);
            // 
            // DepartmentUpdateButton
            // 
            this.DepartmentUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.DepartmentUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DepartmentUpdateButton.FlatAppearance.BorderSize = 0;
            this.DepartmentUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.DepartmentUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DepartmentUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentUpdateButton.ForeColor = System.Drawing.Color.White;
            this.DepartmentUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DepartmentUpdateButton.Location = new System.Drawing.Point(3, 170);
            this.DepartmentUpdateButton.Name = "DepartmentUpdateButton";
            this.DepartmentUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.DepartmentUpdateButton.TabIndex = 52;
            this.DepartmentUpdateButton.Text = "Update";
            this.DepartmentUpdateButton.UseVisualStyleBackColor = false;
            this.DepartmentUpdateButton.Click += new System.EventHandler(this.DepartmentUpdateButton_Click);
            // 
            // tabSchedules
            // 
            this.tabSchedules.Controls.Add(this.panel5);
            this.tabSchedules.Location = new System.Drawing.Point(4, 28);
            this.tabSchedules.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabSchedules.Name = "tabSchedules";
            this.tabSchedules.Size = new System.Drawing.Size(1178, 444);
            this.tabSchedules.TabIndex = 4;
            this.tabSchedules.Text = "Course";
            this.tabSchedules.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.CourseClearButton);
            this.panel5.Controls.Add(this.groupBox2);
            this.panel5.Controls.Add(this.CourseDeleteButton);
            this.panel5.Controls.Add(this.MiscTabCoursesDGV);
            this.panel5.Controls.Add(this.CourseUpdateButton);
            this.panel5.Controls.Add(this.CourseAddButton);
            this.panel5.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1172, 426);
            this.panel5.TabIndex = 13;
            // 
            // CourseClearButton
            // 
            this.CourseClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.CourseClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CourseClearButton.FlatAppearance.BorderSize = 0;
            this.CourseClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.CourseClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CourseClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseClearButton.ForeColor = System.Drawing.Color.White;
            this.CourseClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CourseClearButton.Location = new System.Drawing.Point(269, 211);
            this.CourseClearButton.Name = "CourseClearButton";
            this.CourseClearButton.Size = new System.Drawing.Size(125, 28);
            this.CourseClearButton.TabIndex = 46;
            this.CourseClearButton.Text = "Clear";
            this.CourseClearButton.UseVisualStyleBackColor = false;
            this.CourseClearButton.Click += new System.EventHandler(this.CourseClearButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.CourseIdTextbox);
            this.groupBox2.Controls.Add(this.CourseDescriptionTextbox);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.CourseStatusCombobox);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.CourseNameTextbox);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.CourseDepartmentCombobox);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 202);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Course Details";
            // 
            // CourseIdTextbox
            // 
            this.CourseIdTextbox.Enabled = false;
            this.CourseIdTextbox.Location = new System.Drawing.Point(185, 26);
            this.CourseIdTextbox.Name = "CourseIdTextbox";
            this.CourseIdTextbox.Size = new System.Drawing.Size(100, 27);
            this.CourseIdTextbox.TabIndex = 15;
            // 
            // CourseDescriptionTextbox
            // 
            this.CourseDescriptionTextbox.Location = new System.Drawing.Point(185, 92);
            this.CourseDescriptionTextbox.Name = "CourseDescriptionTextbox";
            this.CourseDescriptionTextbox.Size = new System.Drawing.Size(219, 27);
            this.CourseDescriptionTextbox.TabIndex = 19;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(159, 19);
            this.label16.TabIndex = 10;
            this.label16.Text = "Course Description";
            // 
            // CourseStatusCombobox
            // 
            this.CourseStatusCombobox.FormattingEnabled = true;
            this.CourseStatusCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.CourseStatusCombobox.Location = new System.Drawing.Point(185, 158);
            this.CourseStatusCombobox.Name = "CourseStatusCombobox";
            this.CourseStatusCombobox.Size = new System.Drawing.Size(121, 27);
            this.CourseStatusCombobox.TabIndex = 18;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 19);
            this.label15.TabIndex = 11;
            this.label15.Text = "Course Id";
            // 
            // CourseNameTextbox
            // 
            this.CourseNameTextbox.Location = new System.Drawing.Point(185, 59);
            this.CourseNameTextbox.Name = "CourseNameTextbox";
            this.CourseNameTextbox.Size = new System.Drawing.Size(219, 27);
            this.CourseNameTextbox.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 19);
            this.label14.TabIndex = 12;
            this.label14.Text = "Course Name";
            // 
            // CourseDepartmentCombobox
            // 
            this.CourseDepartmentCombobox.FormattingEnabled = true;
            this.CourseDepartmentCombobox.Items.AddRange(new object[] {
            "0",
            "sdf",
            "1"});
            this.CourseDepartmentCombobox.Location = new System.Drawing.Point(185, 125);
            this.CourseDepartmentCombobox.Name = "CourseDepartmentCombobox";
            this.CourseDepartmentCombobox.Size = new System.Drawing.Size(219, 27);
            this.CourseDepartmentCombobox.TabIndex = 16;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 129);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 19);
            this.label13.TabIndex = 13;
            this.label13.Text = "Department";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 162);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 19);
            this.label12.TabIndex = 14;
            this.label12.Text = "Course Status";
            // 
            // CourseDeleteButton
            // 
            this.CourseDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.CourseDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CourseDeleteButton.FlatAppearance.BorderSize = 0;
            this.CourseDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.CourseDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CourseDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseDeleteButton.ForeColor = System.Drawing.Color.White;
            this.CourseDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CourseDeleteButton.Location = new System.Drawing.Point(138, 211);
            this.CourseDeleteButton.Name = "CourseDeleteButton";
            this.CourseDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.CourseDeleteButton.TabIndex = 45;
            this.CourseDeleteButton.Text = "Delete";
            this.CourseDeleteButton.UseVisualStyleBackColor = false;
            this.CourseDeleteButton.Click += new System.EventHandler(this.CourseDeleteButton_Click);
            // 
            // MiscTabCoursesDGV
            // 
            this.MiscTabCoursesDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabCoursesDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabCoursesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabCoursesDGV.Location = new System.Drawing.Point(442, 8);
            this.MiscTabCoursesDGV.Name = "MiscTabCoursesDGV";
            this.MiscTabCoursesDGV.Size = new System.Drawing.Size(701, 299);
            this.MiscTabCoursesDGV.TabIndex = 9;
            this.MiscTabCoursesDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabCoursesDGV_RowHeaderMouseClick);
            // 
            // CourseUpdateButton
            // 
            this.CourseUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.CourseUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CourseUpdateButton.FlatAppearance.BorderSize = 0;
            this.CourseUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.CourseUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CourseUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseUpdateButton.ForeColor = System.Drawing.Color.White;
            this.CourseUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CourseUpdateButton.Location = new System.Drawing.Point(7, 211);
            this.CourseUpdateButton.Name = "CourseUpdateButton";
            this.CourseUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.CourseUpdateButton.TabIndex = 44;
            this.CourseUpdateButton.Text = "Update";
            this.CourseUpdateButton.UseVisualStyleBackColor = false;
            this.CourseUpdateButton.Click += new System.EventHandler(this.CourseUpdateButton_Click);
            // 
            // CourseAddButton
            // 
            this.CourseAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.CourseAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CourseAddButton.FlatAppearance.BorderSize = 0;
            this.CourseAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.CourseAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CourseAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseAddButton.ForeColor = System.Drawing.Color.White;
            this.CourseAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CourseAddButton.Location = new System.Drawing.Point(442, 313);
            this.CourseAddButton.Name = "CourseAddButton";
            this.CourseAddButton.Size = new System.Drawing.Size(125, 28);
            this.CourseAddButton.TabIndex = 43;
            this.CourseAddButton.Text = "Add Course";
            this.CourseAddButton.UseVisualStyleBackColor = false;
            this.CourseAddButton.Click += new System.EventHandler(this.CourseAddButton_Click);
            // 
            // tabAttendance
            // 
            this.tabAttendance.Controls.Add(this.panel6);
            this.tabAttendance.Location = new System.Drawing.Point(4, 28);
            this.tabAttendance.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabAttendance.Name = "tabAttendance";
            this.tabAttendance.Size = new System.Drawing.Size(1178, 444);
            this.tabAttendance.TabIndex = 5;
            this.tabAttendance.Text = "Subjects";
            this.tabAttendance.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.SubjectClearButton);
            this.panel6.Controls.Add(this.groupBox6);
            this.panel6.Controls.Add(this.SubjectDeleteButton);
            this.panel6.Controls.Add(this.MiscTabSubjectDGV);
            this.panel6.Controls.Add(this.SujectUpdateButton);
            this.panel6.Controls.Add(this.SubjectAddButton);
            this.panel6.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1146, 426);
            this.panel6.TabIndex = 13;
            // 
            // SubjectClearButton
            // 
            this.SubjectClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.SubjectClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SubjectClearButton.FlatAppearance.BorderSize = 0;
            this.SubjectClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.SubjectClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubjectClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubjectClearButton.ForeColor = System.Drawing.Color.White;
            this.SubjectClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SubjectClearButton.Location = new System.Drawing.Point(265, 232);
            this.SubjectClearButton.Name = "SubjectClearButton";
            this.SubjectClearButton.Size = new System.Drawing.Size(125, 28);
            this.SubjectClearButton.TabIndex = 50;
            this.SubjectClearButton.Text = "Clear";
            this.SubjectClearButton.UseVisualStyleBackColor = false;
            this.SubjectClearButton.Click += new System.EventHandler(this.SubjectClearButton_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.SubjectCourseCombobox);
            this.groupBox6.Controls.Add(this.SubjectUnitsToCompleteTextbox);
            this.groupBox6.Controls.Add(this.SubjectIdTextbox);
            this.groupBox6.Controls.Add(this.SubjectDescriptionTextbox);
            this.groupBox6.Controls.Add(this.SubjectNameTextbox);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Location = new System.Drawing.Point(3, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(440, 223);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Subject Details";
            // 
            // SubjectCourseCombobox
            // 
            this.SubjectCourseCombobox.FormattingEnabled = true;
            this.SubjectCourseCombobox.Location = new System.Drawing.Point(197, 166);
            this.SubjectCourseCombobox.Name = "SubjectCourseCombobox";
            this.SubjectCourseCombobox.Size = new System.Drawing.Size(231, 27);
            this.SubjectCourseCombobox.TabIndex = 24;
            // 
            // SubjectUnitsToCompleteTextbox
            // 
            this.SubjectUnitsToCompleteTextbox.Location = new System.Drawing.Point(197, 133);
            this.SubjectUnitsToCompleteTextbox.Name = "SubjectUnitsToCompleteTextbox";
            this.SubjectUnitsToCompleteTextbox.Size = new System.Drawing.Size(100, 27);
            this.SubjectUnitsToCompleteTextbox.TabIndex = 23;
            // 
            // SubjectIdTextbox
            // 
            this.SubjectIdTextbox.Location = new System.Drawing.Point(197, 35);
            this.SubjectIdTextbox.Name = "SubjectIdTextbox";
            this.SubjectIdTextbox.Size = new System.Drawing.Size(100, 27);
            this.SubjectIdTextbox.TabIndex = 20;
            // 
            // SubjectDescriptionTextbox
            // 
            this.SubjectDescriptionTextbox.Location = new System.Drawing.Point(197, 100);
            this.SubjectDescriptionTextbox.Name = "SubjectDescriptionTextbox";
            this.SubjectDescriptionTextbox.Size = new System.Drawing.Size(230, 27);
            this.SubjectDescriptionTextbox.TabIndex = 22;
            // 
            // SubjectNameTextbox
            // 
            this.SubjectNameTextbox.Location = new System.Drawing.Point(197, 67);
            this.SubjectNameTextbox.Name = "SubjectNameTextbox";
            this.SubjectNameTextbox.Size = new System.Drawing.Size(230, 27);
            this.SubjectNameTextbox.TabIndex = 21;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(19, 104);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(163, 19);
            this.label19.TabIndex = 12;
            this.label19.Text = "Subject Description";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 170);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 19);
            this.label17.TabIndex = 14;
            this.label17.Text = "Course";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(19, 71);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(119, 19);
            this.label21.TabIndex = 10;
            this.label21.Text = "Subject Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 137);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(153, 19);
            this.label18.TabIndex = 13;
            this.label18.Text = "Units To Complete";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(19, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 19);
            this.label20.TabIndex = 11;
            this.label20.Text = "EDP Code";
            // 
            // SubjectDeleteButton
            // 
            this.SubjectDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.SubjectDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SubjectDeleteButton.FlatAppearance.BorderSize = 0;
            this.SubjectDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.SubjectDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubjectDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubjectDeleteButton.ForeColor = System.Drawing.Color.White;
            this.SubjectDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SubjectDeleteButton.Location = new System.Drawing.Point(134, 232);
            this.SubjectDeleteButton.Name = "SubjectDeleteButton";
            this.SubjectDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.SubjectDeleteButton.TabIndex = 49;
            this.SubjectDeleteButton.Text = "Delete";
            this.SubjectDeleteButton.UseVisualStyleBackColor = false;
            this.SubjectDeleteButton.Click += new System.EventHandler(this.SubjectDeleteButton_Click);
            // 
            // MiscTabSubjectDGV
            // 
            this.MiscTabSubjectDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabSubjectDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabSubjectDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabSubjectDGV.Location = new System.Drawing.Point(449, 3);
            this.MiscTabSubjectDGV.Name = "MiscTabSubjectDGV";
            this.MiscTabSubjectDGV.Size = new System.Drawing.Size(603, 223);
            this.MiscTabSubjectDGV.TabIndex = 9;
            this.MiscTabSubjectDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabSubjectDGV_RowHeaderMouseClick);
            // 
            // SujectUpdateButton
            // 
            this.SujectUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.SujectUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SujectUpdateButton.FlatAppearance.BorderSize = 0;
            this.SujectUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.SujectUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SujectUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SujectUpdateButton.ForeColor = System.Drawing.Color.White;
            this.SujectUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SujectUpdateButton.Location = new System.Drawing.Point(3, 232);
            this.SujectUpdateButton.Name = "SujectUpdateButton";
            this.SujectUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.SujectUpdateButton.TabIndex = 48;
            this.SujectUpdateButton.Text = "Update";
            this.SujectUpdateButton.UseVisualStyleBackColor = false;
            this.SujectUpdateButton.Click += new System.EventHandler(this.SujectUpdateButton_Click);
            // 
            // SubjectAddButton
            // 
            this.SubjectAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.SubjectAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SubjectAddButton.FlatAppearance.BorderSize = 0;
            this.SubjectAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.SubjectAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubjectAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubjectAddButton.ForeColor = System.Drawing.Color.White;
            this.SubjectAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SubjectAddButton.Location = new System.Drawing.Point(449, 232);
            this.SubjectAddButton.Name = "SubjectAddButton";
            this.SubjectAddButton.Size = new System.Drawing.Size(125, 28);
            this.SubjectAddButton.TabIndex = 47;
            this.SubjectAddButton.Text = "Add Subject";
            this.SubjectAddButton.UseVisualStyleBackColor = false;
            this.SubjectAddButton.Click += new System.EventHandler(this.SubjectAddButton_Click);
            // 
            // tabFacilities
            // 
            this.tabFacilities.Controls.Add(this.panel10);
            this.tabFacilities.Location = new System.Drawing.Point(4, 28);
            this.tabFacilities.Name = "tabFacilities";
            this.tabFacilities.Padding = new System.Windows.Forms.Padding(3);
            this.tabFacilities.Size = new System.Drawing.Size(1178, 444);
            this.tabFacilities.TabIndex = 6;
            this.tabFacilities.Text = "Facilities";
            this.tabFacilities.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.FacilityClearButton);
            this.panel10.Controls.Add(this.groupBox3);
            this.panel10.Controls.Add(this.FacilityDeleteButton);
            this.panel10.Controls.Add(this.MiscTabFacilitiesDGV);
            this.panel10.Controls.Add(this.FacilityUpdateButton);
            this.panel10.Controls.Add(this.FacilityAddButton);
            this.panel10.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel10.Location = new System.Drawing.Point(8, 8);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1146, 426);
            this.panel10.TabIndex = 13;
            // 
            // FacilityClearButton
            // 
            this.FacilityClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.FacilityClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FacilityClearButton.FlatAppearance.BorderSize = 0;
            this.FacilityClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.FacilityClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FacilityClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FacilityClearButton.ForeColor = System.Drawing.Color.White;
            this.FacilityClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FacilityClearButton.Location = new System.Drawing.Point(265, 166);
            this.FacilityClearButton.Name = "FacilityClearButton";
            this.FacilityClearButton.Size = new System.Drawing.Size(125, 28);
            this.FacilityClearButton.TabIndex = 50;
            this.FacilityClearButton.Text = "Clear";
            this.FacilityClearButton.UseVisualStyleBackColor = false;
            this.FacilityClearButton.Click += new System.EventHandler(this.FacilityClearButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.FacilityIdTextbox);
            this.groupBox3.Controls.Add(this.FacilityDescriptionTextbox);
            this.groupBox3.Controls.Add(this.FacilityNameTextbox);
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(509, 157);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Facility Details";
            // 
            // FacilityIdTextbox
            // 
            this.FacilityIdTextbox.Enabled = false;
            this.FacilityIdTextbox.Location = new System.Drawing.Point(199, 34);
            this.FacilityIdTextbox.Name = "FacilityIdTextbox";
            this.FacilityIdTextbox.Size = new System.Drawing.Size(100, 27);
            this.FacilityIdTextbox.TabIndex = 20;
            // 
            // FacilityDescriptionTextbox
            // 
            this.FacilityDescriptionTextbox.Location = new System.Drawing.Point(199, 100);
            this.FacilityDescriptionTextbox.Name = "FacilityDescriptionTextbox";
            this.FacilityDescriptionTextbox.Size = new System.Drawing.Size(293, 27);
            this.FacilityDescriptionTextbox.TabIndex = 22;
            // 
            // FacilityNameTextbox
            // 
            this.FacilityNameTextbox.Location = new System.Drawing.Point(199, 67);
            this.FacilityNameTextbox.Name = "FacilityNameTextbox";
            this.FacilityNameTextbox.Size = new System.Drawing.Size(293, 27);
            this.FacilityNameTextbox.TabIndex = 21;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(23, 38);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(85, 19);
            this.label41.TabIndex = 17;
            this.label41.Text = "Facility Id";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(23, 104);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(159, 19);
            this.label39.TabIndex = 19;
            this.label39.Text = "Facility Description";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(23, 71);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(115, 19);
            this.label40.TabIndex = 18;
            this.label40.Text = "Facility Name";
            // 
            // FacilityDeleteButton
            // 
            this.FacilityDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.FacilityDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FacilityDeleteButton.FlatAppearance.BorderSize = 0;
            this.FacilityDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.FacilityDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FacilityDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FacilityDeleteButton.ForeColor = System.Drawing.Color.White;
            this.FacilityDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FacilityDeleteButton.Location = new System.Drawing.Point(134, 166);
            this.FacilityDeleteButton.Name = "FacilityDeleteButton";
            this.FacilityDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.FacilityDeleteButton.TabIndex = 49;
            this.FacilityDeleteButton.Text = "Delete";
            this.FacilityDeleteButton.UseVisualStyleBackColor = false;
            this.FacilityDeleteButton.Click += new System.EventHandler(this.FacilityDeleteButton_Click);
            // 
            // MiscTabFacilitiesDGV
            // 
            this.MiscTabFacilitiesDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabFacilitiesDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabFacilitiesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabFacilitiesDGV.Location = new System.Drawing.Point(518, 3);
            this.MiscTabFacilitiesDGV.Name = "MiscTabFacilitiesDGV";
            this.MiscTabFacilitiesDGV.Size = new System.Drawing.Size(488, 157);
            this.MiscTabFacilitiesDGV.TabIndex = 15;
            this.MiscTabFacilitiesDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabFacilitiesDGV_RowHeaderMouseClick);
            // 
            // FacilityUpdateButton
            // 
            this.FacilityUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.FacilityUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FacilityUpdateButton.FlatAppearance.BorderSize = 0;
            this.FacilityUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.FacilityUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FacilityUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FacilityUpdateButton.ForeColor = System.Drawing.Color.White;
            this.FacilityUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FacilityUpdateButton.Location = new System.Drawing.Point(3, 166);
            this.FacilityUpdateButton.Name = "FacilityUpdateButton";
            this.FacilityUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.FacilityUpdateButton.TabIndex = 48;
            this.FacilityUpdateButton.Text = "Update";
            this.FacilityUpdateButton.UseVisualStyleBackColor = false;
            this.FacilityUpdateButton.Click += new System.EventHandler(this.FacilityUpdateButton_Click);
            // 
            // FacilityAddButton
            // 
            this.FacilityAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.FacilityAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FacilityAddButton.FlatAppearance.BorderSize = 0;
            this.FacilityAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.FacilityAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FacilityAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FacilityAddButton.ForeColor = System.Drawing.Color.White;
            this.FacilityAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FacilityAddButton.Location = new System.Drawing.Point(518, 166);
            this.FacilityAddButton.Name = "FacilityAddButton";
            this.FacilityAddButton.Size = new System.Drawing.Size(125, 28);
            this.FacilityAddButton.TabIndex = 47;
            this.FacilityAddButton.Text = "Add Facility";
            this.FacilityAddButton.UseVisualStyleBackColor = false;
            this.FacilityAddButton.Click += new System.EventHandler(this.FacilityAddButton_Click);
            // 
            // tabSchedule
            // 
            this.tabSchedule.Controls.Add(this.panel8);
            this.tabSchedule.Location = new System.Drawing.Point(4, 28);
            this.tabSchedule.Name = "tabSchedule";
            this.tabSchedule.Size = new System.Drawing.Size(1178, 444);
            this.tabSchedule.TabIndex = 7;
            this.tabSchedule.Text = "Schedule";
            this.tabSchedule.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.ScheduleClearButton);
            this.panel8.Controls.Add(this.groupBox8);
            this.panel8.Controls.Add(this.ScheduleDeleteButton);
            this.panel8.Controls.Add(this.MiscTabSchedulesDGV);
            this.panel8.Controls.Add(this.ScheduleUpdateButton);
            this.panel8.Controls.Add(this.ScheduleAddButton);
            this.panel8.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1146, 426);
            this.panel8.TabIndex = 13;
            // 
            // ScheduleClearButton
            // 
            this.ScheduleClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.ScheduleClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ScheduleClearButton.FlatAppearance.BorderSize = 0;
            this.ScheduleClearButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.ScheduleClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ScheduleClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScheduleClearButton.ForeColor = System.Drawing.Color.White;
            this.ScheduleClearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ScheduleClearButton.Location = new System.Drawing.Point(278, 385);
            this.ScheduleClearButton.Name = "ScheduleClearButton";
            this.ScheduleClearButton.Size = new System.Drawing.Size(125, 28);
            this.ScheduleClearButton.TabIndex = 48;
            this.ScheduleClearButton.Text = "Clear";
            this.ScheduleClearButton.UseVisualStyleBackColor = false;
            this.ScheduleClearButton.Click += new System.EventHandler(this.ScheduleClearButton_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.SchedulesInstructorIdCombobox);
            this.groupBox8.Controls.Add(this.ScheduleTimeEndDTP);
            this.groupBox8.Controls.Add(this.ScheduleTimeStartDTP);
            this.groupBox8.Controls.Add(this.ScheduleSemesterTextbox);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Controls.Add(this.ScheduleValidUntilDTP);
            this.groupBox8.Controls.Add(this.ScheduleValidOnDTP);
            this.groupBox8.Controls.Add(this.ScheduleSubjectCombobox);
            this.groupBox8.Controls.Add(this.ScheduleStatusCombobox);
            this.groupBox8.Controls.Add(this.ScheduleFacilityCombobox);
            this.groupBox8.Controls.Add(this.ScheduleIdTextbox);
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Location = new System.Drawing.Point(3, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(440, 363);
            this.groupBox8.TabIndex = 44;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Schedule Details";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(22, 300);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(85, 19);
            this.label49.TabIndex = 37;
            this.label49.Text = "Instructor";
            // 
            // SchedulesInstructorIdCombobox
            // 
            this.SchedulesInstructorIdCombobox.FormattingEnabled = true;
            this.SchedulesInstructorIdCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.SchedulesInstructorIdCombobox.Location = new System.Drawing.Point(202, 296);
            this.SchedulesInstructorIdCombobox.Name = "SchedulesInstructorIdCombobox";
            this.SchedulesInstructorIdCombobox.Size = new System.Drawing.Size(200, 27);
            this.SchedulesInstructorIdCombobox.TabIndex = 36;
            // 
            // ScheduleTimeEndDTP
            // 
            this.ScheduleTimeEndDTP.CustomFormat = "hh:mm";
            this.ScheduleTimeEndDTP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.ScheduleTimeEndDTP.Location = new System.Drawing.Point(202, 130);
            this.ScheduleTimeEndDTP.Name = "ScheduleTimeEndDTP";
            this.ScheduleTimeEndDTP.Size = new System.Drawing.Size(227, 27);
            this.ScheduleTimeEndDTP.TabIndex = 35;
            // 
            // ScheduleTimeStartDTP
            // 
            this.ScheduleTimeStartDTP.CustomFormat = "hh:mm";
            this.ScheduleTimeStartDTP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.ScheduleTimeStartDTP.Location = new System.Drawing.Point(202, 97);
            this.ScheduleTimeStartDTP.Name = "ScheduleTimeStartDTP";
            this.ScheduleTimeStartDTP.Size = new System.Drawing.Size(227, 27);
            this.ScheduleTimeStartDTP.TabIndex = 34;
            // 
            // ScheduleSemesterTextbox
            // 
            this.ScheduleSemesterTextbox.Location = new System.Drawing.Point(202, 329);
            this.ScheduleSemesterTextbox.Name = "ScheduleSemesterTextbox";
            this.ScheduleSemesterTextbox.Size = new System.Drawing.Size(121, 27);
            this.ScheduleSemesterTextbox.TabIndex = 33;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(22, 333);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(81, 19);
            this.label48.TabIndex = 32;
            this.label48.Text = "Semester";
            // 
            // ScheduleValidUntilDTP
            // 
            this.ScheduleValidUntilDTP.CustomFormat = "dd-mmm -yyyy";
            this.ScheduleValidUntilDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ScheduleValidUntilDTP.Location = new System.Drawing.Point(202, 196);
            this.ScheduleValidUntilDTP.Name = "ScheduleValidUntilDTP";
            this.ScheduleValidUntilDTP.Size = new System.Drawing.Size(227, 27);
            this.ScheduleValidUntilDTP.TabIndex = 31;
            // 
            // ScheduleValidOnDTP
            // 
            this.ScheduleValidOnDTP.CustomFormat = "dd-mmm-yyyy";
            this.ScheduleValidOnDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ScheduleValidOnDTP.Location = new System.Drawing.Point(202, 163);
            this.ScheduleValidOnDTP.Name = "ScheduleValidOnDTP";
            this.ScheduleValidOnDTP.Size = new System.Drawing.Size(227, 27);
            this.ScheduleValidOnDTP.TabIndex = 30;
            // 
            // ScheduleSubjectCombobox
            // 
            this.ScheduleSubjectCombobox.FormattingEnabled = true;
            this.ScheduleSubjectCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.ScheduleSubjectCombobox.Location = new System.Drawing.Point(202, 263);
            this.ScheduleSubjectCombobox.Name = "ScheduleSubjectCombobox";
            this.ScheduleSubjectCombobox.Size = new System.Drawing.Size(200, 27);
            this.ScheduleSubjectCombobox.TabIndex = 27;
            // 
            // ScheduleStatusCombobox
            // 
            this.ScheduleStatusCombobox.FormattingEnabled = true;
            this.ScheduleStatusCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.ScheduleStatusCombobox.Location = new System.Drawing.Point(202, 230);
            this.ScheduleStatusCombobox.Name = "ScheduleStatusCombobox";
            this.ScheduleStatusCombobox.Size = new System.Drawing.Size(121, 27);
            this.ScheduleStatusCombobox.TabIndex = 26;
            // 
            // ScheduleFacilityCombobox
            // 
            this.ScheduleFacilityCombobox.FormattingEnabled = true;
            this.ScheduleFacilityCombobox.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.ScheduleFacilityCombobox.Location = new System.Drawing.Point(202, 64);
            this.ScheduleFacilityCombobox.Name = "ScheduleFacilityCombobox";
            this.ScheduleFacilityCombobox.Size = new System.Drawing.Size(227, 27);
            this.ScheduleFacilityCombobox.TabIndex = 25;
            // 
            // ScheduleIdTextbox
            // 
            this.ScheduleIdTextbox.Enabled = false;
            this.ScheduleIdTextbox.Location = new System.Drawing.Point(202, 31);
            this.ScheduleIdTextbox.Name = "ScheduleIdTextbox";
            this.ScheduleIdTextbox.Size = new System.Drawing.Size(121, 27);
            this.ScheduleIdTextbox.TabIndex = 20;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(22, 35);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(102, 19);
            this.label23.TabIndex = 11;
            this.label23.Text = "Schedule Id";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(22, 68);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(112, 19);
            this.label24.TabIndex = 10;
            this.label24.Text = "Facility name";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(22, 101);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 19);
            this.label26.TabIndex = 12;
            this.label26.Text = "Time Start";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(22, 134);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(83, 19);
            this.label27.TabIndex = 13;
            this.label27.Text = "Time End";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(22, 167);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 19);
            this.label28.TabIndex = 14;
            this.label28.Text = "Valid On";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(22, 267);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(116, 19);
            this.label29.TabIndex = 17;
            this.label29.Text = "Subject name";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(22, 234);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(135, 19);
            this.label30.TabIndex = 15;
            this.label30.Text = "Schedule Status";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(22, 200);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(89, 19);
            this.label31.TabIndex = 16;
            this.label31.Text = "Valid Until";
            // 
            // ScheduleDeleteButton
            // 
            this.ScheduleDeleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.ScheduleDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ScheduleDeleteButton.FlatAppearance.BorderSize = 0;
            this.ScheduleDeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.ScheduleDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ScheduleDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScheduleDeleteButton.ForeColor = System.Drawing.Color.White;
            this.ScheduleDeleteButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ScheduleDeleteButton.Location = new System.Drawing.Point(147, 385);
            this.ScheduleDeleteButton.Name = "ScheduleDeleteButton";
            this.ScheduleDeleteButton.Size = new System.Drawing.Size(125, 28);
            this.ScheduleDeleteButton.TabIndex = 47;
            this.ScheduleDeleteButton.Text = "Delete";
            this.ScheduleDeleteButton.UseVisualStyleBackColor = false;
            this.ScheduleDeleteButton.Click += new System.EventHandler(this.ScheduleDeleteButton_Click);
            // 
            // MiscTabSchedulesDGV
            // 
            this.MiscTabSchedulesDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabSchedulesDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabSchedulesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabSchedulesDGV.Location = new System.Drawing.Point(449, 3);
            this.MiscTabSchedulesDGV.Name = "MiscTabSchedulesDGV";
            this.MiscTabSchedulesDGV.Size = new System.Drawing.Size(646, 363);
            this.MiscTabSchedulesDGV.TabIndex = 9;
            this.MiscTabSchedulesDGV.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MiscTabSchedulesDGV_RowHeaderMouseClick);
            // 
            // ScheduleUpdateButton
            // 
            this.ScheduleUpdateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.ScheduleUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ScheduleUpdateButton.FlatAppearance.BorderSize = 0;
            this.ScheduleUpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.ScheduleUpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ScheduleUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScheduleUpdateButton.ForeColor = System.Drawing.Color.White;
            this.ScheduleUpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ScheduleUpdateButton.Location = new System.Drawing.Point(16, 385);
            this.ScheduleUpdateButton.Name = "ScheduleUpdateButton";
            this.ScheduleUpdateButton.Size = new System.Drawing.Size(125, 28);
            this.ScheduleUpdateButton.TabIndex = 46;
            this.ScheduleUpdateButton.Text = "Update";
            this.ScheduleUpdateButton.UseVisualStyleBackColor = false;
            this.ScheduleUpdateButton.Click += new System.EventHandler(this.ScheduleUpdateButton_Click);
            // 
            // ScheduleAddButton
            // 
            this.ScheduleAddButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.ScheduleAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ScheduleAddButton.FlatAppearance.BorderSize = 0;
            this.ScheduleAddButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.ScheduleAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ScheduleAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScheduleAddButton.ForeColor = System.Drawing.Color.White;
            this.ScheduleAddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ScheduleAddButton.Location = new System.Drawing.Point(429, 385);
            this.ScheduleAddButton.Name = "ScheduleAddButton";
            this.ScheduleAddButton.Size = new System.Drawing.Size(125, 28);
            this.ScheduleAddButton.TabIndex = 45;
            this.ScheduleAddButton.Text = "Add Schedule";
            this.ScheduleAddButton.UseVisualStyleBackColor = false;
            this.ScheduleAddButton.Click += new System.EventHandler(this.ScheduleAddButton_Click);
            // 
            // tabAttendace
            // 
            this.tabAttendace.Controls.Add(this.panel9);
            this.tabAttendace.Location = new System.Drawing.Point(4, 28);
            this.tabAttendace.Name = "tabAttendace";
            this.tabAttendace.Size = new System.Drawing.Size(1178, 444);
            this.tabAttendace.TabIndex = 8;
            this.tabAttendace.Text = "Attendance";
            this.tabAttendace.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.AttendanceSearchTextbox);
            this.panel9.Controls.Add(this.groupBox1);
            this.panel9.Controls.Add(this.label32);
            this.panel9.Controls.Add(this.AttendanceFindButton);
            this.panel9.Controls.Add(this.MiscTabAttendanceDGV);
            this.panel9.Font = new System.Drawing.Font("Gotham Book", 12F);
            this.panel9.Location = new System.Drawing.Point(3, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1146, 426);
            this.panel9.TabIndex = 13;
            // 
            // AttendanceSearchTextbox
            // 
            this.AttendanceSearchTextbox.Location = new System.Drawing.Point(66, 224);
            this.AttendanceSearchTextbox.Name = "AttendanceSearchTextbox";
            this.AttendanceSearchTextbox.Size = new System.Drawing.Size(287, 27);
            this.AttendanceSearchTextbox.TabIndex = 29;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.AttendanceScheduleIdTextbox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.AttendanceStudentIdTextbox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.TimeOutDTP);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.TimeInDTP);
            this.groupBox1.Controls.Add(this.AttendanceDateDTP);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(432, 215);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Attendance record details";
            // 
            // AttendanceScheduleIdTextbox
            // 
            this.AttendanceScheduleIdTextbox.Location = new System.Drawing.Point(187, 166);
            this.AttendanceScheduleIdTextbox.Name = "AttendanceScheduleIdTextbox";
            this.AttendanceScheduleIdTextbox.Size = new System.Drawing.Size(200, 27);
            this.AttendanceScheduleIdTextbox.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Owner Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attendance date";
            // 
            // AttendanceStudentIdTextbox
            // 
            this.AttendanceStudentIdTextbox.Location = new System.Drawing.Point(187, 34);
            this.AttendanceStudentIdTextbox.Name = "AttendanceStudentIdTextbox";
            this.AttendanceStudentIdTextbox.Size = new System.Drawing.Size(200, 27);
            this.AttendanceStudentIdTextbox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 19);
            this.label4.TabIndex = 2;
            this.label4.Text = "Time IN";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 19);
            this.label5.TabIndex = 3;
            this.label5.Text = "Time OUT";
            // 
            // TimeOutDTP
            // 
            this.TimeOutDTP.CustomFormat = "hh:mm:ss";
            this.TimeOutDTP.Enabled = false;
            this.TimeOutDTP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.TimeOutDTP.Location = new System.Drawing.Point(187, 133);
            this.TimeOutDTP.Name = "TimeOutDTP";
            this.TimeOutDTP.Size = new System.Drawing.Size(200, 27);
            this.TimeOutDTP.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 19);
            this.label6.TabIndex = 4;
            this.label6.Text = "Schedule Id";
            // 
            // TimeInDTP
            // 
            this.TimeInDTP.CustomFormat = "hh:mm:ss";
            this.TimeInDTP.Enabled = false;
            this.TimeInDTP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.TimeInDTP.Location = new System.Drawing.Point(187, 100);
            this.TimeInDTP.Name = "TimeInDTP";
            this.TimeInDTP.Size = new System.Drawing.Size(200, 27);
            this.TimeInDTP.TabIndex = 6;
            // 
            // AttendanceDateDTP
            // 
            this.AttendanceDateDTP.CustomFormat = "dd-mm-yyyy";
            this.AttendanceDateDTP.Enabled = false;
            this.AttendanceDateDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.AttendanceDateDTP.Location = new System.Drawing.Point(187, 67);
            this.AttendanceDateDTP.Name = "AttendanceDateDTP";
            this.AttendanceDateDTP.Size = new System.Drawing.Size(200, 27);
            this.AttendanceDateDTP.TabIndex = 5;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(15, 228);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(44, 19);
            this.label32.TabIndex = 12;
            this.label32.Text = "Find";
            // 
            // AttendanceFindButton
            // 
            this.AttendanceFindButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.AttendanceFindButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.AttendanceFindButton.FlatAppearance.BorderSize = 0;
            this.AttendanceFindButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.AttendanceFindButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AttendanceFindButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttendanceFindButton.ForeColor = System.Drawing.Color.White;
            this.AttendanceFindButton.Image = global::_1._1_FDCForLabMonitoringSystem.Properties.Resources.search_9_16;
            this.AttendanceFindButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AttendanceFindButton.Location = new System.Drawing.Point(359, 223);
            this.AttendanceFindButton.Name = "AttendanceFindButton";
            this.AttendanceFindButton.Size = new System.Drawing.Size(71, 28);
            this.AttendanceFindButton.TabIndex = 39;
            this.AttendanceFindButton.Text = "Go";
            this.AttendanceFindButton.UseVisualStyleBackColor = false;
            this.AttendanceFindButton.Click += new System.EventHandler(this.AttendanceFindButton_Click);
            // 
            // MiscTabAttendanceDGV
            // 
            this.MiscTabAttendanceDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MiscTabAttendanceDGV.BackgroundColor = System.Drawing.Color.White;
            this.MiscTabAttendanceDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MiscTabAttendanceDGV.Location = new System.Drawing.Point(441, 3);
            this.MiscTabAttendanceDGV.Name = "MiscTabAttendanceDGV";
            this.MiscTabAttendanceDGV.Size = new System.Drawing.Size(702, 215);
            this.MiscTabAttendanceDGV.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(48)))), ((int)(((byte)(166)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1206, 5);
            this.panel4.TabIndex = 10;
            // 
            // MiscTabForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1206, 545);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.MiscTabMainTab);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MiscTabForms";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MiscTabForms";
            this.Load += new System.EventHandler(this.MiscTabForms_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.MiscTabMainTab.ResumeLayout(false);
            this.tabStudents.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabStudentsDGV)).EndInit();
            this.tabInstuctors.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabInstrutorsDGV)).EndInit();
            this.tabLaboratoryStaffs.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabLaboratoryStaffDGV)).EndInit();
            this.tabDepartment.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabDepartmentsDGV)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabSchedules.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabCoursesDGV)).EndInit();
            this.tabAttendance.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabSubjectDGV)).EndInit();
            this.tabFacilities.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabFacilitiesDGV)).EndInit();
            this.tabSchedule.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabSchedulesDGV)).EndInit();
            this.tabAttendace.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MiscTabAttendanceDGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl MiscTabMainTab;
        private System.Windows.Forms.TabPage tabStudents;
        private System.Windows.Forms.TabPage tabInstuctors;
        private System.Windows.Forms.TabPage tabLaboratoryStaffs;
        private System.Windows.Forms.TabPage tabDepartment;
        private System.Windows.Forms.TabPage tabSchedules;
        private System.Windows.Forms.TabPage tabAttendance;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView MiscTabStudentsDGV;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView MiscTabCoursesDGV;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView MiscTabSubjectDGV;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DataGridView MiscTabLaboratoryStaffDGV;
        private System.Windows.Forms.DataGridView MiscTabSchedulesDGV;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AttendanceStudentIdTextbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker TimeOutDTP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker TimeInDTP;
        private System.Windows.Forms.DateTimePicker AttendanceDateDTP;
        private System.Windows.Forms.DataGridView MiscTabAttendanceDGV;
        private System.Windows.Forms.Button StudentClearButton;
        private System.Windows.Forms.Button StudentDeleteButton;
        private System.Windows.Forms.Button StudentUpdateButton;
        private System.Windows.Forms.Button StudentAddButton;
        private System.Windows.Forms.Button CourseClearButton;
        private System.Windows.Forms.Button CourseDeleteButton;
        private System.Windows.Forms.Button CourseUpdateButton;
        private System.Windows.Forms.Button CourseAddButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox CourseIdTextbox;
        private System.Windows.Forms.TextBox CourseDescriptionTextbox;
        private System.Windows.Forms.ComboBox CourseStatusCombobox;
        private System.Windows.Forms.TextBox CourseNameTextbox;
        private System.Windows.Forms.ComboBox CourseDepartmentCombobox;
        private System.Windows.Forms.Button AttendanceFindButton;
        private System.Windows.Forms.TabPage tabFacilities;
        private System.Windows.Forms.Button FacilityClearButton;
        private System.Windows.Forms.Button FacilityDeleteButton;
        private System.Windows.Forms.Button FacilityUpdateButton;
        private System.Windows.Forms.Button FacilityAddButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox FacilityIdTextbox;
        private System.Windows.Forms.TextBox FacilityDescriptionTextbox;
        private System.Windows.Forms.TextBox FacilityNameTextbox;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.DataGridView MiscTabFacilitiesDGV;
        private System.Windows.Forms.TabPage tabSchedule;
        private System.Windows.Forms.Button InstructorClearButton;
        private System.Windows.Forms.Button InstructorDeleteButton;
        private System.Windows.Forms.Button InstructorUpdateButton;
        private System.Windows.Forms.Button InstructorAddButton;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox InstructorPositionTextbox;
        private System.Windows.Forms.ComboBox InstructorUserStatusCombobox;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox InstructorMiddleNameTextbox;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox InstructorIdTextbox;
        private System.Windows.Forms.TextBox InstructorLastNameTextbox;
        private System.Windows.Forms.TextBox InstructorFirstNameTextbox;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.DataGridView MiscTabInstrutorsDGV;
        private System.Windows.Forms.Button StaffClearButton;
        private System.Windows.Forms.Button StaffDeleteButton;
        private System.Windows.Forms.Button StaffUpdateButton;
        private System.Windows.Forms.Button StaffAddButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox StaffPositionTextbox;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox StaffMiddleNameTextbox;
        private System.Windows.Forms.ComboBox StaffUserStatusCombobox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox StaffLastNameTextbox;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox StaffFirstNameTextbox;
        private System.Windows.Forms.TextBox StaffIdTextbox;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox StudentUserStatusCombobox;
        private System.Windows.Forms.ComboBox StudentCourseLevelCombobox;
        private System.Windows.Forms.ComboBox StudentCourseCombobox;
        private System.Windows.Forms.ComboBox StudentDepartmentCombobox;
        private System.Windows.Forms.ComboBox StudentGenderCombobox;
        private System.Windows.Forms.TextBox StudentFirstNameTextbox;
        private System.Windows.Forms.TextBox StudentMiddleNameTextbox;
        private System.Windows.Forms.TextBox StudentLastNameTextbox;
        private System.Windows.Forms.Button SubjectClearButton;
        private System.Windows.Forms.Button SubjectDeleteButton;
        private System.Windows.Forms.Button SujectUpdateButton;
        private System.Windows.Forms.Button SubjectAddButton;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox SubjectCourseCombobox;
        private System.Windows.Forms.TextBox SubjectUnitsToCompleteTextbox;
        private System.Windows.Forms.TextBox SubjectIdTextbox;
        private System.Windows.Forms.TextBox SubjectDescriptionTextbox;
        private System.Windows.Forms.TextBox SubjectNameTextbox;
        private System.Windows.Forms.Button ScheduleClearButton;
        private System.Windows.Forms.Button ScheduleDeleteButton;
        private System.Windows.Forms.Button ScheduleUpdateButton;
        private System.Windows.Forms.Button ScheduleAddButton;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DateTimePicker ScheduleValidUntilDTP;
        private System.Windows.Forms.DateTimePicker ScheduleValidOnDTP;
        private System.Windows.Forms.ComboBox ScheduleSubjectCombobox;
        private System.Windows.Forms.ComboBox ScheduleStatusCombobox;
        private System.Windows.Forms.ComboBox ScheduleFacilityCombobox;
        private System.Windows.Forms.TextBox ScheduleIdTextbox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox StudentIdTextbox;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TabPage tabAttendace;
        private System.Windows.Forms.DataGridView MiscTabDepartmentsDGV;
        private System.Windows.Forms.Button DepartmentClearButton;
        private System.Windows.Forms.Button DepartmentDeleteButton;
        private System.Windows.Forms.Button DepartmentUpdateButton;
        private System.Windows.Forms.Button DepartmentAddButton;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox DepartmentIdTextbox;
        private System.Windows.Forms.TextBox DepartmentDescriptionTextbox;
        private System.Windows.Forms.TextBox DepartmentNameTextbox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox AttendanceSearchTextbox;
        private System.Windows.Forms.TextBox AttendanceScheduleIdTextbox;
        private System.Windows.Forms.TextBox ScheduleSemesterTextbox;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.DateTimePicker ScheduleTimeEndDTP;
        private System.Windows.Forms.DateTimePicker ScheduleTimeStartDTP;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.ComboBox SchedulesInstructorIdCombobox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox StudentPCNo;
        private System.Windows.Forms.Label label50;
    }
}