﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._1_FDCForLabMonitoringSystem.Properties
{
    public partial class Enrollment_list : Form
    {
        public Enrollment_list()
        {
            InitializeComponent();
        }
    }
}
